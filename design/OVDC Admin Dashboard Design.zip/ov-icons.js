(function () {
  function pascal(n) { return n.split('-').map(function (s) { return s.charAt(0).toUpperCase() + s.slice(1); }).join(''); }
  class OvIcon extends HTMLElement {
    static get observedAttributes() { return ['name', 'size', 'stroke']; }
    constructor() { super(); this._root = this.attachShadow({ mode: 'open' }); }
    connectedCallback() { this.render(); }
    attributeChangedCallback() { if (this.isConnected) this.render(); }
    render() {
      var L = window.lucide;
      var s = this.getAttribute('size') || '16';
      this._root.innerHTML = '<style>:host{display:inline-flex;flex:none;width:' + s + 'px;height:' + s + 'px;vertical-align:middle}svg{display:block}</style>';
      if (!L || !L.icons) { var self = this; clearTimeout(this._t); this._t = setTimeout(function () { self.render(); }, 120); return; }
      var node = L.icons[pascal(this.getAttribute('name') || 'circle')];
      if (!node) return;
      var el = L.createElement(node);
      el.setAttribute('width', s); el.setAttribute('height', s);
      el.setAttribute('stroke-width', this.getAttribute('stroke') || '1.75');
      this._root.appendChild(el);
    }
  }
  if (!customElements.get('ov-icon')) customElements.define('ov-icon', OvIcon);
})();
