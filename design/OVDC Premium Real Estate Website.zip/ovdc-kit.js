/* OVDC shared sample data + helpers. One source of truth for every page (projects, unit 14B, inventory, plans). */
(function () {
  if (window.OVDC) return;
  const FX = { LKR: 1, USD: 300, AUD: 198, AED: 81.7 }; // LKR per 1 unit of currency (sample rates, Oct 2026)
  const CURRENCIES = ['LKR', 'USD', 'AUD', 'AED'];
  const LANGS = [{ k: 'en', label: 'English', short: 'EN' }, { k: 'si', label: 'සිංහල', short: 'සි' }, { k: 'ta', label: 'தமிழ்', short: 'த' }];
  const ls = { get: (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} } };

  const mn = v => (v % 1 === 0 ? String(v) : v.toFixed(1));
  function money(lkrMn, cur) {
    cur = cur || 'LKR';
    if (lkrMn == null) return 'Price on launch';
    if (cur === 'LKR') return 'LKR ' + mn(lkrMn) + ' Mn';
    const v = Math.round(lkrMn * 1e6 / FX[cur] / 1000) * 1000;
    return cur + ' ' + v.toLocaleString('en-US');
  }
  function price(lkrMn, cur) { return { primary: money(lkrMn, cur), secondary: cur && cur !== 'LKR' && lkrMn != null ? money(lkrMn, 'LKR') : '' }; }
  function perSqft(lkrMn, sqft, cur) { cur = cur || 'LKR'; const v = lkrMn * 1e6 / sqft / FX[cur]; return cur + ' ' + Math.round(v).toLocaleString('en-US') + ' / sqft'; }
  function lkrFull(n) { return 'LKR ' + Math.round(n).toLocaleString('en-US'); }

  const STATUS = {
    A: { k: 'A', key: 'available', label: 'Available', fill: 'var(--status-available)', on: 'var(--status-available-on)', tint: 'var(--status-available-tint)' },
    R: { k: 'R', key: 'reserved', label: 'Reserved', fill: 'var(--status-reserved)', on: 'var(--status-reserved-on)', tint: 'var(--status-reserved-tint)' },
    S: { k: 'S', key: 'sold', label: 'Sold', fill: 'var(--status-sold)', on: 'var(--status-sold-on)', tint: 'var(--status-sold-tint)' },
    B: { k: 'B', key: 'blocked', label: 'Not released', fill: 'var(--status-blocked-hatch)', on: 'var(--status-blocked-on)', tint: 'var(--status-blocked-hatch)' }
  };
  const PROJECT_STATUS = { done: 'Completed', uc: 'Under construction', soon: 'Upcoming' };

  const projects = [
    { id: 'ovr', name: 'Ocean View Residences', loc: 'Mount Lavinia', type: 'Apartments', status: 'uc', from: 68.5, tour: true, progress: 62, completion: 'Dec 2027', uda: 'UDA/DC/2023/0412', units: 240, floors: 24, towers: 'Tower A · Tower B', beds: '2–4 Bed', available: 71, lat: 6.8390, lng: 79.8650, blurb: 'Two sea-facing towers on the Mount Lavinia shoreline, two minutes’ walk from the beach.' },
    { id: 'marine', name: 'The Marine Crest', loc: 'Colombo 03', type: 'Luxury apartments', status: 'uc', from: 112, tour: true, progress: 38, completion: 'Jun 2028', uda: 'UDA/DC/2024/0187', units: 96, floors: 32, towers: 'Single tower', beds: '3–4 Bed', available: 41, lat: 6.9108, lng: 79.8497, blurb: 'Thirty-two floors on Marine Drive with full-width ocean terraces and a sky pool.' },
    { id: 'lagoon', name: 'Lagoon Terraces', loc: 'Negombo', type: 'Townhouses', status: 'uc', from: 54, tour: false, progress: 81, completion: 'Mar 2027', uda: 'UDA/DC/2023/0655', units: 48, floors: 3, towers: '48 townhouses', beds: '3 Bed', available: 9, lat: 7.2090, lng: 79.8380, blurb: 'Three-storey townhouses facing the Negombo lagoon, each with a private roof garden.' },
    { id: 'kandy', name: 'Kandy Hill Villas', loc: 'Kandy', type: 'Villas', status: 'soon', from: null, tour: false, progress: 0, completion: 'Launching 2027', uda: 'Approval in progress', units: 22, floors: 2, towers: '22 villas', beds: '4 Bed', available: 22, lat: 7.2906, lng: 80.6337, blurb: 'Twenty-two hillside villas above the Mahaweli, with valley views and private pools.' },
    { id: 'battaramulla', name: 'Battaramulla Park', loc: 'Battaramulla', type: 'Apartments', status: 'soon', from: null, tour: false, progress: 0, completion: 'Launching 2027', uda: 'Approval in progress', units: 180, floors: 20, towers: 'Twin towers', beds: '2–3 Bed', available: 180, lat: 6.9000, lng: 79.9180, blurb: 'Park-side apartments five minutes from the Parliament and the Diyawanna Oya walkways.' },
    { id: 'ward', name: 'Ward Place Residences', loc: 'Colombo 07', type: 'Apartments', status: 'done', from: 96, tour: true, progress: 100, completion: 'Handed over 2023', uda: 'UDA/DC/2019/0233', units: 64, floors: 18, towers: 'Single tower', beds: '3 Bed', available: 3, lat: 6.9160, lng: 79.8680, blurb: 'Eighteen floors on a quiet Colombo 07 avenue. Three final residences remain.' },
    { id: 'rajagiriya', name: 'Rajagiriya Gardens', loc: 'Rajagiriya', type: 'Apartments', status: 'done', from: null, tour: false, progress: 100, completion: 'Handed over 2021', uda: 'UDA/DC/2017/0098', units: 120, floors: 15, towers: 'Twin towers', beds: '2–3 Bed', available: 0, lat: 6.9100, lng: 79.8950, blurb: 'Garden-court apartments off Kotte Road. Sold out and fully occupied.' }
  ];

  /* Ocean View Residences floor plate (6 units per floor) */
  const PLATE = [
    { u: 'A', type: 'Type A', beds: 2, label: '2 Bed', baths: 2, sqft: 1480, balcony: 160, facing: 'West', view: 'Sea' },
    { u: 'B', type: 'Type C', beds: 3, label: '3 Bed + study', baths: 3.5, sqft: 1980, balcony: 240, facing: 'West', view: 'Sea' },
    { u: 'C', type: 'Type B', beds: 2, label: '2 Bed + study', baths: 2.5, sqft: 1725, balcony: 190, facing: 'North-west', view: 'Sea' },
    { u: 'D', type: 'Type C', beds: 3, label: '3 Bed + study', baths: 3.5, sqft: 1980, balcony: 220, facing: 'East', view: 'City' },
    { u: 'E', type: 'Type A', beds: 2, label: '2 Bed', baths: 2, sqft: 1480, balcony: 160, facing: 'East', view: 'City' },
    { u: 'F', type: 'Type D', beds: 4, label: '4 Bed', baths: 4.5, sqft: 2650, balcony: 420, facing: 'South-west', view: 'Sea' }
  ];
  const unitPrice = (f, p) => Math.round(p.sqft * (47000 + f * 40) * (p.view === 'Sea' ? 1 : 0.98) / 1e5) / 10;
  const OVERRIDE = { 'A14': 'SAAARA', 'A5': 'SRASAA' };
  function buildTower(t, top, notReleasedFrom) {
    const floors = [];
    for (let f = 3; f <= top; f++) {
      const units = PLATE.map((p, i) => {
        let s;
        if (f >= notReleasedFrom) s = 'B';
        else { const h = (f * 7 + i * 13 + (t === 'B' ? 3 : 0)) % 10; const soldCut = f < 10 ? 6 : f < 17 ? 4 : 2; s = h < soldCut ? 'S' : h < soldCut + 2 ? 'R' : 'A'; }
        const o = OVERRIDE[t + f]; if (o) s = o[i];
        const pr = unitPrice(f, p);
        if (s === 'A' && pr < 68.5) s = 'S';
        return { ...p, id: f + p.u, tower: t, floor: f, status: s, price: pr };
      });
      floors.push({ n: f, units, available: units.filter(u => u.status === 'A').length, from: Math.min(...units.filter(u => u.status === 'A').map(u => u.price).concat([Infinity])) });
    }
    return floors.reverse();
  }
  const towers = { A: buildTower('A', 24, 22), B: buildTower('B', 20, 12) };
  projects[0].available = ['A', 'B'].reduce((n, t) => n + towers[t].reduce((m, f) => m + f.available, 0), 0);
  const findUnit = (t, id) => { for (const fl of towers[t]) for (const u of fl.units) if (u.id === id) return u; return null; };

  const unit14B = Object.assign({}, findUnit('A', '14B'), {
    project: 'ovr', projectName: 'Ocean View Residences', ref: 'Tower A · Unit 14B', price: 94.2, parking: '2 bays', view: 'Sea · Indian Ocean', interior: 1980, completion: 'Dec 2027', ceiling: '3.2 m',
    rooms: [
      { name: 'Living & dining', dim: '7.2 × 5.4 m' }, { name: 'Kitchen', dim: '4.2 × 3.0 m' }, { name: 'Master bedroom', dim: '5.0 × 4.2 m' },
      { name: 'Bedroom 2', dim: '4.0 × 3.6 m' }, { name: 'Bedroom 3', dim: '3.8 × 3.4 m' }, { name: 'Study', dim: '2.8 × 2.6 m' }, { name: 'Balcony', dim: '8.0 × 2.8 m' }
    ]
  });

  const paymentPlan = [
    { stage: 'Reservation fee', pct: 0, fixed: 0.5, when: 'On reservation', note: 'LKR 500,000, adjusted against booking', state: 'paid', date: '12 Jan 2026' },
    { stage: 'Booking & sale agreement', pct: 20, when: 'Within 14 days', state: 'paid', date: '26 Jan 2026' },
    { stage: 'Substructure complete', pct: 10, when: 'Completed', state: 'paid', date: '15 Mar 2026' },
    { stage: '8th floor slab', pct: 10, when: 'Completed', state: 'paid', date: '20 Jul 2026' },
    { stage: '16th floor slab', pct: 10, when: 'Due 15 Oct 2026', state: 'overdue', date: '15 Oct 2026' },
    { stage: 'Roof slab', pct: 10, when: 'Est. Mar 2027', state: 'due', date: 'Mar 2027' },
    { stage: 'Façade & glazing', pct: 10, when: 'Est. Jun 2027', state: 'due', date: 'Jun 2027' },
    { stage: 'Finishing works', pct: 10, when: 'Est. Sep 2027', state: 'due', date: 'Sep 2027' },
    { stage: 'Handover', pct: 20, when: 'Dec 2027', state: 'due', date: 'Dec 2027' }
  ];

  const progress = [
    { month: 'Oct 2026', pct: 62, a: 68, b: 54, note: '17th floor slab poured in Tower A. Tower B at level 12.' },
    { month: 'Sep 2026', pct: 58, a: 64, b: 50, note: 'Façade mock-up approved. Glazing order placed.' },
    { month: 'Aug 2026', pct: 54, a: 59, b: 47, note: 'Pool deck waterproofing complete on the podium.' },
    { month: 'Jul 2026', pct: 50, a: 55, b: 43, note: '8th floor slab handed over to MEP contractors.' },
    { month: 'Jun 2026', pct: 46, a: 50, b: 40, note: 'Tower B core reaches level 10.' },
    { month: 'May 2026', pct: 41, a: 45, b: 36, note: 'Basement car park slab complete.' }
  ];

  const nearby = [
    { cat: 'Lifestyle', name: 'Mount Lavinia Beach', min: 2, mode: 'walk', lat: 6.8370, lng: 79.8612 },
    { cat: 'Transport', name: 'Mount Lavinia Railway Station', min: 5, mode: 'walk', lat: 6.8327, lng: 79.8644 },
    { cat: 'Schools', name: 'S. Thomas’ College', min: 4, mode: 'drive', lat: 6.8402, lng: 79.8668 },
    { cat: 'Hospitals', name: 'Colombo South Teaching Hospital', min: 9, mode: 'drive', lat: 6.8668, lng: 79.8768 },
    { cat: 'Lifestyle', name: 'Dehiwala Zoo', min: 8, mode: 'drive', lat: 6.8566, lng: 79.8742 },
    { cat: 'Malls', name: 'Majestic City, Colombo 04', min: 18, mode: 'drive', lat: 6.8936, lng: 79.8553 },
    { cat: 'Business', name: 'Colombo Fort', min: 30, mode: 'drive', lat: 6.9344, lng: 79.8428 },
    { cat: 'Transport', name: 'Bandaranaike International Airport', min: 60, mode: 'drive', lat: 7.1808, lng: 79.8841 }
  ];

  const company = { name: 'Ocean View Development Company (Pvt) Ltd', short: 'OVDC', hotline: '+94 11 234 5678', whatsapp: '+94 77 123 4567', email: 'sales@ovdc.lk', web: 'ovdc.lk', address: 'No. 42, Marine Drive, Colombo 03', hours: 'Mon–Sat 9.00 am – 6.00 pm · Sun 10.00 am – 4.00 pm', reg: 'PV 00123456' };

  /* currency + language (persisted, broadcast to every instance) */
  const bus = new EventTarget();
  function getCurrency() { return ls.get('ovdc.currency', 'LKR'); }
  function setCurrency(c) { ls.set('ovdc.currency', c); bus.dispatchEvent(new CustomEvent('currency', { detail: c })); }
  function getLang() { return ls.get('ovdc.lang', 'en'); }
  function setLang(l) { ls.set('ovdc.lang', l); bus.dispatchEvent(new CustomEvent('lang', { detail: l })); }
  function on(ev, cb) { const h = e => cb(e.detail); bus.addEventListener(ev, h); return () => bus.removeEventListener(ev, h); }

  /* shortlist */
  function getShortlist() { try { return JSON.parse(ls.get('ovdc.shortlist', '["A-14B","A-14C","A-21F"]')); } catch (e) { return []; } }
  function setShortlist(a) { ls.set('ovdc.shortlist', JSON.stringify(a)); bus.dispatchEvent(new CustomEvent('shortlist', { detail: a })); }

  /* Leaflet map helper (loads Leaflet once) */
  let leafletP = null;
  function loadLeaflet() {
    if (window.L) return Promise.resolve(window.L);
    if (leafletP) return leafletP;
    leafletP = new Promise((ok, no) => {
      const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
      const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => ok(window.L); s.onerror = no; document.head.appendChild(s);
    });
    return leafletP;
  }
  async function map(el, opts) {
    const L = await loadLeaflet();
    const m = L.map(el, { zoomControl: false, attributionControl: true, scrollWheelZoom: false }).setView(opts.center, opts.zoom || 13);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/' + (opts.dark ? 'dark_all' : 'light_all') + '/{z}/{x}/{y}{r}.png', { attribution: '© OpenStreetMap · © CARTO', maxZoom: 19 }).addTo(m);
    L.control.zoom({ position: 'bottomright' }).addTo(m);
    const layer = L.layerGroup().addTo(m);
    const api = {
      map: m,
      pins(list) {
        layer.clearLayers();
        list.forEach(p => {
          const html = p.kind === 'dot'
            ? `<div style="width:14px;height:14px;border-radius:50%;background:${p.color || 'var(--color-navy)'};border:2px solid var(--color-cream);box-shadow:0 2px 6px rgba(0,0,0,.3)"></div>`
            : `<div style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;padding:6px 10px;font:600 12px Archivo,sans-serif;letter-spacing:.02em;background:${p.active ? 'var(--color-gold)' : 'var(--color-navy)'};color:${p.active ? 'var(--color-navy)' : 'var(--color-ivory)'};box-shadow:0 6px 16px rgba(15,27,45,.3);transform:translate(-50%,-100%);position:relative">${p.label}<span style="position:absolute;left:50%;bottom:-6px;width:10px;height:10px;margin-left:-5px;background:inherit;transform:rotate(45deg)"></span></div>`;
          const mk = L.marker([p.lat, p.lng], { icon: L.divIcon({ html, className: '', iconSize: [0, 0] }), title: p.title || p.label, keyboard: true }).addTo(layer);
          if (p.onClick) mk.on('click', p.onClick);
        });
      },
      fit(list, pad) { if (list.length) m.fitBounds(L.latLngBounds(list.map(p => [p.lat, p.lng])), { padding: [pad || 60, pad || 60] }); },
      destroy() { m.remove(); }
    };
    if (opts.pins) api.pins(opts.pins);
    setTimeout(() => m.invalidateSize(), 200);
    return api;
  }

  /* fade-up on scroll — standalone pages only (canvas boards keep everything visible) */
  function initReveal() {
    if (document.querySelector('meta[name="design_doc_mode"]') || !('IntersectionObserver' in window)) return;
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    document.documentElement.setAttribute('data-reveal-ready', '');
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.setAttribute('data-in', ''); io.unobserve(e.target); } }), { threshold: .12 });
    const scan = () => document.querySelectorAll('[data-reveal]:not([data-in])').forEach(el => io.observe(el));
    scan(); new MutationObserver(scan).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initReveal); else setTimeout(initReveal, 0);

  window.OVDC = { FX, CURRENCIES, LANGS, money, price, perSqft, lkrFull, STATUS, PROJECT_STATUS, projects, project: id => projects.find(p => p.id === id), PLATE, towers, findUnit, unit14B, paymentPlan, progress, nearby, company, getCurrency, setCurrency, getLang, setLang, on, getShortlist, setShortlist, map, loadLeaflet };
})();
