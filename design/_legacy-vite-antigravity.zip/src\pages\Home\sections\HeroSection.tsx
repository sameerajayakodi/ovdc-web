// ============================================================
// OVDC — Hero Section
// ============================================================
import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Play } from 'lucide-react';
import './HeroSection.css';

const SLIDES = [
  {
    type: 'image' as const,
    url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1920&q=90',
    headline: 'Where the Ocean\nMeets Luxury',
    sub: 'Premium coastal residences crafted for those who demand the extraordinary',
  },
  {
    type: 'image' as const,
    url: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1920&q=90',
    headline: 'Redefining\nCoastal Living',
    sub: 'Discover villas and apartments with breathtaking ocean panoramas',
  },
  {
    type: 'image' as const,
    url: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1920&q=90',
    headline: 'Your Dream\nHome Awaits',
    sub: 'Explore 360° virtual tours of our finest residences across Sri Lanka',
  },
];

export default function HeroSection() {
  const [current, setCurrent] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    setLoaded(true);
    intervalRef.current = setInterval(() => {
      setCurrent((c) => (c + 1) % SLIDES.length);
    }, 6000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const slide = SLIDES[current];

  return (
    <section className="hero-section" aria-label="Hero banner">
      {/* Background slides */}
      {SLIDES.map((s, i) => (
        <div
          key={i}
          className={`hero-slide ${i === current ? 'active' : ''}`}
          style={{ backgroundImage: `url(${s.url})` }}
          aria-hidden={i !== current}
        />
      ))}

      {/* Gradient overlay */}
      <div className="hero-overlay" />

      {/* Content */}
      <div className={`hero-content container ${loaded ? 'visible' : ''}`}>
        <p className="hero-label">Ocean View Development Company</p>
        <h1 className="hero-headline">
          {slide.headline.split('\n').map((line, i) => (
            <span key={i}>{line}<br /></span>
          ))}
        </h1>
        <p className="hero-sub">{slide.sub}</p>
        <div className="hero-actions">
          <Link to="/properties" className="btn btn-primary hero-btn" id="hero-explore-btn">
            Explore Properties
          </Link>
          <Link to="/properties?tour=360" className="btn btn-outline hero-btn" id="hero-tour-btn">
            <Play size={16} />
            Virtual Tours
          </Link>
        </div>
      </div>

      {/* Slide indicators */}
      <div className="hero-indicators" role="tablist" aria-label="Slide indicators">
        {SLIDES.map((_, i) => (
          <button
            key={i}
            role="tab"
            aria-selected={i === current}
            aria-label={`Slide ${i + 1}`}
            className={`hero-dot ${i === current ? 'active' : ''}`}
            onClick={() => setCurrent(i)}
          />
        ))}
      </div>

      {/* Scroll down */}
      <a href="#stats" className="hero-scroll-hint" aria-label="Scroll down">
        <span className="scroll-label">Scroll</span>
        <ChevronDown size={20} className="scroll-icon" />
      </a>
    </section>
  );
}
