// ============================================================
// OVDC — Contact CTA Section
// ============================================================
import { Link } from 'react-router-dom';
import { Phone, Mail, MessageSquare } from 'lucide-react';
import './ContactCTA.css';

export default function ContactCTA() {
  return (
    <section className="cta-section">
      <div className="cta-bg" />
      <div className="cta-overlay" />
      <div className="container cta-content" data-aos="fade-up">
        <span className="section-label" style={{ color: 'rgba(201,168,76,0.9)' }}>Get In Touch</span>
        <h2 className="section-title light cta-title">
          Your Dream Home<br />Is One Call Away
        </h2>
        <span className="gold-divider center" />
        <p className="section-desc light" style={{ margin: '16px auto 0' }}>
          Our property consultants are ready to guide you through every step — from choosing the right unit to securing your investment.
        </p>
        <div className="cta-actions">
          <a href="tel:+94771234567" className="btn btn-primary" id="cta-call-btn">
            <Phone size={16} />
            Call Us Now
          </a>
          <a href="https://wa.me/94771234567" target="_blank" rel="noopener noreferrer" className="btn btn-outline" id="cta-whatsapp-btn">
            <MessageSquare size={16} />
            WhatsApp
          </a>
          <Link to="/contact" className="btn btn-outline-gold" id="cta-contact-btn">
            <Mail size={16} />
            Send Inquiry
          </Link>
        </div>
      </div>
    </section>
  );
}
