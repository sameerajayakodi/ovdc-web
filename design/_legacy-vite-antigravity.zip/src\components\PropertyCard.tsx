// ============================================================
// OVDC — Property Card Component
// ============================================================
import { Link } from 'react-router-dom';
import { Bed, Bath, Maximize2, MapPin, Eye } from 'lucide-react';
import type { Property } from '../../types';
import { formatPrice, formatArea, typeLabel } from '../../utils/helpers';
import './PropertyCard.css';

interface Props {
  property: Property;
}

export default function PropertyCard({ property }: Props) {
  const statusClass = `status-${property.status}`;
  const has360 = property.panoramaImages.length > 0;

  return (
    <Link to={`/properties/${property.id}`} className="property-card" id={`property-card-${property.id}`}>
      {/* Image */}
      <div className="pc-image-wrap">
        <img
          src={property.images[0]}
          alt={property.title}
          className="pc-image"
          loading="lazy"
        />
        <div className="pc-overlay" />

        {/* Badges */}
        <div className="pc-badges">
          <span className={`status-chip ${statusClass}`}>
            {property.status === 'under_construction' ? 'Under Construction' :
             property.status === 'available' ? 'Available' : 'Sold'}
          </span>
          {has360 && (
            <span className="badge badge-360 pc-360-badge">
              <Eye size={10} />
              360°
            </span>
          )}
        </div>

        {/* Type */}
        <div className="pc-type">{typeLabel(property.type)}</div>
      </div>

      {/* Content */}
      <div className="pc-content">
        <h3 className="pc-title">{property.title}</h3>

        <div className="pc-location">
          <MapPin size={13} />
          <span>{property.location}</span>
        </div>

        <div className="pc-specs">
          {property.bedrooms > 0 && (
            <div className="pc-spec">
              <Bed size={14} />
              <span>{property.bedrooms} Bed{property.bedrooms !== 1 ? 's' : ''}</span>
            </div>
          )}
          <div className="pc-spec">
            <Bath size={14} />
            <span>{property.bathrooms} Bath{property.bathrooms !== 1 ? 's' : ''}</span>
          </div>
          <div className="pc-spec">
            <Maximize2 size={14} />
            <span>{formatArea(property.area)}</span>
          </div>
        </div>

        <div className="pc-footer">
          <div className="pc-price">{formatPrice(property.price, property.currency)}</div>
          <span className="pc-view-btn">View Details →</span>
        </div>
      </div>
    </Link>
  );
}
