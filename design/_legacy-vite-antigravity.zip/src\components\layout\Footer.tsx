// ============================================================
// OVDC — Footer Component
// ============================================================
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Instagram, Linkedin, Youtube } from 'lucide-react';
import './Footer.css';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="ovdc-footer">
      <div className="footer-main container">
        <div className="footer-brand">
          <div className="footer-logo">
            <span className="footer-logo-text">OVDC</span>
            <span className="footer-logo-sub">Ocean View Development Company</span>
          </div>
          <p className="footer-tagline">
            Building dreams on Sri Lanka's most breathtaking coastlines. 
            Premium residences crafted with passion, precision, and a deep respect for the natural world.
          </p>
          <div className="footer-socials">
            <a href="https://facebook.com/ovdc" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><Facebook size={18} /></a>
            <a href="https://instagram.com/ovdc" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><Instagram size={18} /></a>
            <a href="https://linkedin.com/company/ovdc" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"><Linkedin size={18} /></a>
            <a href="https://youtube.com/@ovdc" target="_blank" rel="noopener noreferrer" aria-label="YouTube"><Youtube size={18} /></a>
          </div>
        </div>

        <div className="footer-links-col">
          <h4 className="footer-col-title">Quick Links</h4>
          <ul className="footer-link-list">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/properties">Properties</Link></li>
            <li><Link to="/projects">Projects</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        <div className="footer-links-col">
          <h4 className="footer-col-title">Properties</h4>
          <ul className="footer-link-list">
            <li><Link to="/properties?type=apartment">Apartments</Link></li>
            <li><Link to="/properties?type=villa">Villas</Link></li>
            <li><Link to="/properties?type=penthouse">Penthouses</Link></li>
            <li><Link to="/properties?type=studio">Studios</Link></li>
            <li><Link to="/properties?status=available">Available Units</Link></li>
          </ul>
        </div>

        <div className="footer-contact-col">
          <h4 className="footer-col-title">Contact Us</h4>
          <ul className="footer-contact-list">
            <li>
              <MapPin size={15} />
              <span>No. 42, Galle Road, Colombo 03, Sri Lanka</span>
            </li>
            <li>
              <Phone size={15} />
              <a href="tel:+94771234567">+94 77 123 4567</a>
            </li>
            <li>
              <Mail size={15} />
              <a href="mailto:info@ovdc.lk">info@ovdc.lk</a>
            </li>
          </ul>
          <a
            href="https://wa.me/94771234567"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary footer-cta"
          >
            WhatsApp Us
          </a>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container footer-bottom-inner">
          <p>© {year} OVDC — Ocean View Development Company. All rights reserved.</p>
          <p>
            <Link to="/admin">Admin Panel</Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
