// ============================================================
// OVDC — Projects Preview Section
// ============================================================
import { Link } from 'react-router-dom';
import { MapPin, ArrowRight } from 'lucide-react';
import { useOvdcStore } from '../../../store/ovdcStore';
import './ProjectsPreview.css';

export default function ProjectsPreview() {
  const { projects } = useOvdcStore();
  const featured = projects.slice(0, 3);

  return (
    <section className="projects-preview section-padding bg-navy-gradient">
      <div className="container">
        <div className="pp-header" data-aos="fade-up">
          <span className="section-label" style={{ color: 'rgba(201,168,76,0.9)' }}>Our Portfolio</span>
          <h2 className="section-title light">Landmark Developments</h2>
          <span className="gold-divider center" />
          <p className="section-desc light" style={{ margin: '16px auto 0' }}>
            From vibrant Colombo high-rises to serene coastal villas — our projects define a new standard for residential excellence in Sri Lanka.
          </p>
        </div>

        <div className="pp-grid">
          {featured.map((project, i) => (
            <Link
              to={`/projects`}
              key={project.id}
              className={`pp-card ${i === 0 ? 'pp-card-featured' : ''}`}
              data-aos="fade-up"
              data-aos-delay={i * 120}
            >
              <img src={project.heroImage} alt={project.name} className="pp-card-img" />
              <div className="pp-card-overlay" />
              <div className="pp-card-content">
                <span className={`status-chip status-${project.status}`}>{
                  project.status === 'under_construction' ? 'Under Construction' :
                  project.status.charAt(0).toUpperCase() + project.status.slice(1)
                }</span>
                <h3 className="pp-card-title">{project.name}</h3>
                <div className="pp-card-location">
                  <MapPin size={13} />
                  {project.location}
                </div>
                <p className="pp-card-desc">{project.shortDescription}</p>
                <div className="pp-card-footer">
                  <span>{project.totalUnits} Units</span>
                  <span className="pp-card-link">
                    View Project <ArrowRight size={14} />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="pp-cta" data-aos="fade-up">
          <Link to="/projects" className="btn btn-outline" id="pp-all-projects-btn">
            All Projects <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
