// ============================================================
// OVDC — Stats Counter Section
// ============================================================
import { useEffect, useRef, useState } from 'react';
import { useOvdcStore } from '../../../store/ovdcStore';
import './StatsSection.css';

function useCounter(target: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    const step = Math.ceil(target / (duration / 16));
    let current = 0;
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      setCount(current);
      if (current >= target) clearInterval(timer);
    }, 16);
    return () => clearInterval(timer);
  }, [target, duration, start]);
  return count;
}

interface StatItemProps {
  value: number;
  suffix: string;
  label: string;
  started: boolean;
}

function StatItem({ value, suffix, label, started }: StatItemProps) {
  const count = useCounter(value, 2200, started);
  return (
    <div className="stat-item">
      <div className="stat-value">
        {count.toLocaleString()}<span className="stat-suffix">{suffix}</span>
      </div>
      <div className="stat-label">{label}</div>
      <div className="stat-bar" />
    </div>
  );
}

export default function StatsSection() {
  const { settings } = useOvdcStore();
  const sectionRef = useRef<HTMLElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.4 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="stats" className="stats-section" ref={sectionRef}>
      <div className="container">
        <div className="stats-grid">
          <StatItem value={settings.yearsExperience} suffix="+" label="Years of Excellence" started={started} />
          <StatItem value={settings.totalProjects}   suffix="+" label="Landmark Projects"   started={started} />
          <StatItem value={settings.completedProjects} suffix="" label="Completed Developments" started={started} />
          <StatItem value={settings.happyClients}    suffix="+" label="Happy Clients"        started={started} />
        </div>
      </div>
    </section>
  );
}
