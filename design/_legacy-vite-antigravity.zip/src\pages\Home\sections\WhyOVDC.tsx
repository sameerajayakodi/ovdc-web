// ============================================================
// OVDC — Why OVDC Section
// ============================================================
import { Shield, Award, Users, Layers } from 'lucide-react';
import './WhyOVDC.css';

const VALUES = [
  {
    icon: Shield,
    title: 'Trust & Integrity',
    desc: 'Built on a foundation of transparency and honest communication, we have earned the trust of thousands of clients by consistently delivering on every promise.',
  },
  {
    icon: Award,
    title: 'Excellence',
    desc: 'Driven by a passion for perfection, we uphold the highest construction standards in every development, creating homes that embody quality and lasting value.',
  },
  {
    icon: Layers,
    title: 'Innovation',
    desc: 'Through forward-thinking design, cutting-edge technology, and sustainable building practices, we continuously redefine what modern coastal living means in Sri Lanka.',
  },
  {
    icon: Users,
    title: 'Community',
    desc: 'We build more than homes — we create vibrant communities where neighbours become friends and every resident feels a genuine sense of belonging.',
  },
];

export default function WhyOVDC() {
  return (
    <section className="why-section section-padding">
      <div className="container">
        <div className="why-header" data-aos="fade-up">
          <span className="section-label">Why Choose Us</span>
          <h2 className="section-title">The OVDC Difference</h2>
          <span className="gold-divider" />
          <p className="section-desc">
            Our approach begins with a thorough understanding of what makes a perfect home — combining location, lifestyle, and lasting investment value.
          </p>
        </div>

        <div className="why-grid">
          {VALUES.map((v, i) => {
            const Icon = v.icon;
            return (
              <div key={i} className="why-card" data-aos="fade-up" data-aos-delay={i * 100}>
                <div className="why-icon-wrap">
                  <Icon size={28} className="why-icon" />
                </div>
                <h3 className="why-title">{v.title}</h3>
                <p className="why-desc">{v.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
