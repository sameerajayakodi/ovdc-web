// ============================================================
// OVDC — Utility Helpers
// ============================================================

/** Format price in LKR or USD */
export function formatPrice(price: number, currency: 'LKR' | 'USD'): string {
  if (currency === 'LKR') {
    if (price >= 1_000_000) {
      return `LKR ${(price / 1_000_000).toFixed(1)}M`;
    }
    return `LKR ${price.toLocaleString()}`;
  }
  return `USD ${price.toLocaleString()}`;
}

/** Format area with commas */
export function formatArea(area: number): string {
  return `${area.toLocaleString()} sq.ft`;
}

/** Generate a short UUID-like id */
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

/** Map status to display label */
export function statusLabel(status: string): string {
  const map: Record<string, string> = {
    available: 'Available',
    sold: 'Sold',
    under_construction: 'Under Construction',
    completed: 'Completed',
    ongoing: 'Ongoing',
    upcoming: 'Upcoming',
    new: 'New',
    contacted: 'Contacted',
    closed: 'Closed',
  };
  return map[status] ?? status;
}

/** Map property type to display label */
export function typeLabel(type: string): string {
  const map: Record<string, string> = {
    apartment: 'Apartment',
    villa: 'Villa',
    penthouse: 'Penthouse',
    studio: 'Studio',
    duplex: 'Duplex',
  };
  return map[type] ?? type;
}

/** Truncate text */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trimEnd() + '…';
}

/** Format date */
export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}
