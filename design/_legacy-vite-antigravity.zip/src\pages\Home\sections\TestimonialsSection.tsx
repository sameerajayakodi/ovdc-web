// ============================================================
// OVDC — Testimonials Section
// ============================================================
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import { Star, Quote } from 'lucide-react';
import 'swiper/css';
import 'swiper/css/pagination';
import './TestimonialsSection.css';

const TESTIMONIALS = [
  {
    name: 'Priya & Vikram Subramaniam',
    role: 'Ocean Tower, Unit 24F',
    text: 'The ocean views from our apartment are absolutely mesmerising. OVDC didn\'t just build us a home — they created a sanctuary where every morning begins with the sound of the sea. The 360° virtual tour made us fall in love with the property before we even visited in person.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/80?img=11',
  },
  {
    name: 'Chaminda & Nilanthi Perera',
    role: 'Harbour Residences, Galle',
    text: 'We were looking for a retirement home with character and sea views. OVDC delivered beyond our expectations. The quality of construction is exceptional, the team was always transparent, and our investment has already appreciated significantly.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/80?img=32',
  },
  {
    name: 'James & Sarah Whitfield',
    role: 'Coastal Villas, Unawatuna',
    text: 'As overseas investors, trust was paramount. OVDC\'s transparency throughout the purchase process was refreshing. The property management team has been outstanding. Our villa generates excellent rental returns when we\'re not in Sri Lanka.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/80?img=56',
  },
  {
    name: 'Roshan Jayasekara',
    role: 'Ocean Tower, Studio',
    text: 'The smart studio design is incredible — I never feel like I\'m living in a small space. OVDC thought of everything. The building amenities are world-class and the concierge team genuinely cares about residents.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/80?img=4',
  },
];

export default function TestimonialsSection() {
  return (
    <section className="testimonials-section section-padding">
      <div className="container">
        <div className="testi-header" data-aos="fade-up">
          <span className="section-label">Client Stories</span>
          <h2 className="section-title">What Our Residents Say</h2>
          <span className="gold-divider center" />
        </div>

        <Swiper
          modules={[Autoplay, Pagination]}
          spaceBetween={24}
          slidesPerView={1}
          pagination={{ clickable: true }}
          autoplay={{ delay: 6000, disableOnInteraction: false }}
          breakpoints={{ 768: { slidesPerView: 2 } }}
          className="testi-swiper"
          data-aos="fade-up"
          data-aos-delay="100"
        >
          {TESTIMONIALS.map((t, i) => (
            <SwiperSlide key={i}>
              <div className="testi-card">
                <Quote size={32} className="testi-quote-icon" />
                <div className="testi-stars">
                  {Array.from({ length: t.rating }).map((_, si) => (
                    <Star key={si} size={14} fill="currentColor" />
                  ))}
                </div>
                <p className="testi-text">{t.text}</p>
                <div className="testi-author">
                  <img src={t.avatar} alt={t.name} className="testi-avatar" />
                  <div>
                    <div className="testi-name">{t.name}</div>
                    <div className="testi-role">{t.role}</div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}
