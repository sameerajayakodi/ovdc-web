// ============================================================
// OVDC — Featured Properties Section
// ============================================================
import { Link } from 'react-router-dom';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import PropertyCard from '../../../components/PropertyCard';
import { useOvdcStore } from '../../../store/ovdcStore';
import './FeaturedProperties.css';

export default function FeaturedProperties() {
  const { properties } = useOvdcStore();
  const featured = properties.filter((p) => p.featured);

  return (
    <section className="featured-section section-padding">
      <div className="container">
        <div className="section-header" data-aos="fade-up">
          <span className="section-label">Portfolio</span>
          <h2 className="section-title">Featured Properties</h2>
          <span className="gold-divider" />
          <p className="section-desc">
            Handpicked residences representing the finest in coastal luxury living — each one a masterclass in design, comfort, and ocean-facing elegance.
          </p>
        </div>

        <div className="fp-swiper-wrap" data-aos="fade-up" data-aos-delay="100">
          <Swiper
            modules={[Navigation, Pagination, Autoplay]}
            spaceBetween={24}
            slidesPerView={1}
            navigation
            pagination={{ clickable: true }}
            autoplay={{ delay: 5000, disableOnInteraction: false, pauseOnMouseEnter: true }}
            breakpoints={{
              640:  { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
            className="fp-swiper"
          >
            {featured.map((p) => (
              <SwiperSlide key={p.id}>
                <PropertyCard property={p} />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>

        <div className="fp-cta" data-aos="fade-up">
          <Link to="/properties" className="btn btn-outline-gold" id="fp-view-all-btn">
            View All Properties →
          </Link>
        </div>
      </div>
    </section>
  );
}
