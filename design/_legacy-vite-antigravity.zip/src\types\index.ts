// ============================================================
// OVDC — Type Definitions
// ============================================================

export type PropertyType = 'apartment' | 'villa' | 'penthouse' | 'studio' | 'duplex';
export type PropertyStatus = 'available' | 'sold' | 'under_construction';
export type ProjectStatus = 'completed' | 'ongoing' | 'upcoming';
export type InquiryStatus = 'new' | 'contacted' | 'closed';
export type Currency = 'LKR' | 'USD';

export interface Property {
  id: string;
  title: string;
  type: PropertyType;
  status: PropertyStatus;
  price: number;
  currency: Currency;
  location: string;
  city: string;
  bedrooms: number;
  bathrooms: number;
  area: number; // sq ft
  floor?: number;
  totalFloors?: number;
  description: string;
  shortDescription: string;
  amenities: string[];
  images: string[];
  panoramaImages: PanoramaScene[];
  floorPlanImage?: string;
  projectId?: string;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PanoramaScene {
  id: string;
  label: string;           // e.g. "Living Room"
  imageUrl: string;        // equirectangular URL
  hotSpots?: PanoramaHotSpot[];
}

export interface PanoramaHotSpot {
  pitch: number;
  yaw: number;
  type: 'info' | 'scene';
  text?: string;
  sceneId?: string;
}

export interface Project {
  id: string;
  name: string;
  location: string;
  city: string;
  status: ProjectStatus;
  totalUnits: number;
  completionYear: number;
  startYear: number;
  description: string;
  shortDescription: string;
  heroImage: string;
  images: string[];
  amenities: string[];
  featured: boolean;
  createdAt: string;
}

export interface Inquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  propertyId?: string;
  propertyTitle?: string;
  status: InquiryStatus;
  createdAt: string;
}

export interface SiteSettings {
  companyName: string;
  tagline: string;
  phone: string;
  email: string;
  address: string;
  whatsapp: string;
  facebook: string;
  instagram: string;
  linkedin: string;
  youtube: string;
  heroVideoUrl: string;
  yearsExperience: number;
  totalProjects: number;
  completedProjects: number;
  happyClients: number;
  adminPassword: string;
}

export interface AdminState {
  isAuthenticated: boolean;
  properties: Property[];
  projects: Project[];
  inquiries: Inquiry[];
  settings: SiteSettings;
}
