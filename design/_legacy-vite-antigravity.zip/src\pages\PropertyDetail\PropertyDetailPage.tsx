// ============================================================
// OVDC — Property Detail Page (with 360° Pannellum Viewer)
// ============================================================
import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Bed, Bath, Maximize2, MapPin, ChevronLeft, X, Eye, Phone, Check } from 'lucide-react';
import { useOvdcStore } from '../../store/ovdcStore';
import { formatPrice, formatArea, typeLabel, statusLabel, generateId, formatDate } from '../../utils/helpers';
import PanoramaViewer from './PanoramaViewer';
import type { Inquiry } from '../../types';
import './PropertyDetailPage.css';

export default function PropertyDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { properties, addInquiry } = useOvdcStore();
  const navigate = useNavigate();

  const property = properties.find((p) => p.id === id);

  const [activeImg,    setActiveImg]    = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activePano,   setActivePano]   = useState(0);
  const [showPano,     setShowPano]     = useState(false);
  const [inquirySent,  setInquirySent]  = useState(false);

  // Inquiry form
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });

  if (!property) {
    return (
      <div className="pd-not-found">
        <h2>Property Not Found</h2>
        <Link to="/properties" className="btn btn-navy">← Back to Properties</Link>
      </div>
    );
  }

  const handleInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    const inquiry: Inquiry = {
      id: generateId(),
      ...form,
      propertyId: property.id,
      propertyTitle: property.title,
      status: 'new',
      createdAt: new Date().toISOString(),
    };
    addInquiry(inquiry);
    setInquirySent(true);
    setForm({ name: '', email: '', phone: '', message: '' });
  };

  const statusClass = `status-${property.status}`;

  return (
    <div className="pd-page">
      {/* Breadcrumb */}
      <div className="pd-breadcrumb bg-navy-gradient">
        <div className="container pd-breadcrumb-inner">
          <button onClick={() => navigate(-1)} className="pd-back-btn">
            <ChevronLeft size={16} /> Back
          </button>
          <span className="pd-breadcrumb-path">
            Properties / {typeLabel(property.type)} / {property.city}
          </span>
        </div>
      </div>

      <div className="container pd-layout">
        {/* === LEFT COLUMN === */}
        <div className="pd-left">
          {/* Gallery */}
          <div className="pd-gallery">
            <div className="pd-main-img-wrap" onClick={() => setLightboxOpen(true)}>
              <img src={property.images[activeImg]} alt={property.title} className="pd-main-img" />
              <div className="pd-img-zoom-hint">
                <Maximize2 size={18} /> Click to enlarge
              </div>
            </div>
            <div className="pd-thumbs">
              {property.images.map((img, i) => (
                <button key={i} className={`pd-thumb ${i === activeImg ? 'active' : ''}`} onClick={() => setActiveImg(i)}>
                  <img src={img} alt={`View ${i + 1}`} />
                </button>
              ))}
            </div>
          </div>

          {/* 360° Virtual Tour */}
          {property.panoramaImages.length > 0 && (
            <div className="pd-pano-section">
              <div className="pd-section-header">
                <h2 className="pd-section-title"><Eye size={20} /> 360° Virtual Tour</h2>
              </div>

              {!showPano ? (
                <div className="pd-pano-placeholder">
                  <img src={property.images[0]} alt="Virtual tour preview" className="pd-pano-preview-img" />
                  <div className="pd-pano-start-overlay">
                    <button
                      className="pd-pano-start-btn"
                      onClick={() => setShowPano(true)}
                      id="start-360-tour-btn"
                    >
                      <Eye size={24} />
                      Launch 360° Tour
                    </button>
                    <p>Explore this property in immersive 360°</p>
                  </div>
                </div>
              ) : (
                <>
                  {/* Room selector */}
                  <div className="pd-pano-tabs">
                    {property.panoramaImages.map((scene, i) => (
                      <button
                        key={scene.id}
                        className={`pd-pano-tab ${i === activePano ? 'active' : ''}`}
                        onClick={() => setActivePano(i)}
                        id={`pano-tab-${scene.id}`}
                      >
                        {scene.label}
                      </button>
                    ))}
                  </div>
                  <PanoramaViewer scene={property.panoramaImages[activePano]} />
                  <p className="pd-pano-hint">
                    💡 Drag to look around • Scroll to zoom • Double-click to move
                  </p>
                </>
              )}
            </div>
          )}

          {/* Floor Plan */}
          {property.floorPlanImage && (
            <div className="pd-floorplan-section">
              <div className="pd-section-header">
                <h2 className="pd-section-title">Floor Plan</h2>
              </div>
              <img src={property.floorPlanImage} alt="Floor plan" className="pd-floorplan-img" />
            </div>
          )}

          {/* Amenities */}
          <div className="pd-amenities-section">
            <div className="pd-section-header">
              <h2 className="pd-section-title">Amenities & Features</h2>
            </div>
            <div className="pd-amenities-grid">
              {property.amenities.map((a) => (
                <div key={a} className="pd-amenity">
                  <Check size={14} className="pd-amenity-check" />
                  {a}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* === RIGHT COLUMN === */}
        <div className="pd-right">
          {/* Property summary card */}
          <div className="pd-summary-card">
            <div className="pd-badges">
              <span className={`status-chip ${statusClass}`}>{statusLabel(property.status)}</span>
              <span className="badge badge-gold">{typeLabel(property.type)}</span>
              {property.panoramaImages.length > 0 && (
                <span className="badge badge-360"><Eye size={10} /> 360°</span>
              )}
            </div>

            <h1 className="pd-title">{property.title}</h1>

            <div className="pd-location">
              <MapPin size={15} />
              <span>{property.location}</span>
            </div>

            <div className="pd-price">{formatPrice(property.price, property.currency)}</div>

            <div className="pd-specs-row">
              {property.bedrooms > 0 && (
                <div className="pd-spec">
                  <Bed size={18} />
                  <span>{property.bedrooms}<br /><small>Beds</small></span>
                </div>
              )}
              <div className="pd-spec">
                <Bath size={18} />
                <span>{property.bathrooms}<br /><small>Baths</small></span>
              </div>
              <div className="pd-spec">
                <Maximize2 size={18} />
                <span>{formatArea(property.area)}<br /><small>Area</small></span>
              </div>
              {property.floor && (
                <div className="pd-spec">
                  <span style={{ fontSize: 18, fontWeight: 700 }}>{property.floor}</span>
                  <span>Floor<br /><small>of {property.totalFloors}</small></span>
                </div>
              )}
            </div>

            <div className="pd-desc-preview">
              <p>{property.shortDescription}</p>
            </div>

            <div className="pd-contact-actions">
              <a href="tel:+94771234567" className="btn btn-primary pd-action-btn" id="pd-call-btn">
                <Phone size={16} /> Call Agent
              </a>
              <a href="https://wa.me/94771234567" target="_blank" rel="noopener noreferrer" className="btn btn-navy pd-action-btn" id="pd-wa-btn">
                WhatsApp
              </a>
            </div>
          </div>

          {/* Description */}
          <div className="pd-desc-card">
            <h2 className="pd-section-title" style={{ fontSize: 18, marginBottom: 12 }}>About this Property</h2>
            <p className="pd-desc">{property.description}</p>
            <p className="pd-meta-note">Listed: {formatDate(property.createdAt)}</p>
          </div>

          {/* Inquiry Form */}
          <div className="pd-inquiry-card" id="inquiry-form">
            <h2 className="pd-section-title" style={{ fontSize: 18, marginBottom: 4 }}>Send an Inquiry</h2>
            <p className="pd-inquiry-sub">We'll get back to you within 24 hours.</p>

            {inquirySent ? (
              <div className="pd-inquiry-success">
                <Check size={28} />
                <p>Thank you! Your inquiry has been received.<br />Our team will contact you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleInquiry} className="pd-inquiry-form">
                <div className="form-group">
                  <label htmlFor="inq-name" className="form-label">Full Name *</label>
                  <input id="inq-name" className="form-input" required value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} placeholder="Your full name" />
                </div>
                <div className="form-group">
                  <label htmlFor="inq-email" className="form-label">Email *</label>
                  <input id="inq-email" type="email" className="form-input" required value={form.email} onChange={(e) => setForm({...form, email: e.target.value})} placeholder="your@email.com" />
                </div>
                <div className="form-group">
                  <label htmlFor="inq-phone" className="form-label">Phone</label>
                  <input id="inq-phone" type="tel" className="form-input" value={form.phone} onChange={(e) => setForm({...form, phone: e.target.value})} placeholder="+94 77 xxx xxxx" />
                </div>
                <div className="form-group">
                  <label htmlFor="inq-message" className="form-label">Message</label>
                  <textarea id="inq-message" className="form-textarea" value={form.message} onChange={(e) => setForm({...form, message: e.target.value})} placeholder={`I'm interested in ${property.title}…`} />
                </div>
                <button type="submit" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} id="inq-submit-btn">
                  Send Inquiry
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <div className="lightbox-overlay" onClick={() => setLightboxOpen(false)}>
          <button className="lb-close" onClick={() => setLightboxOpen(false)} aria-label="Close lightbox">
            <X size={28} />
          </button>
          <img
            src={property.images[activeImg]}
            alt={property.title}
            className="lb-img"
            onClick={(e) => e.stopPropagation()}
          />
          {property.images.length > 1 && (
            <div className="lb-thumbs" onClick={(e) => e.stopPropagation()}>
              {property.images.map((img, i) => (
                <button key={i} className={`lb-thumb ${i === activeImg ? 'active' : ''}`} onClick={() => setActiveImg(i)}>
                  <img src={img} alt={`View ${i + 1}`} />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
