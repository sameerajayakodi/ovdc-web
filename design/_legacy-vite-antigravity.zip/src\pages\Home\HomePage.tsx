// ============================================================
// OVDC — Home Page
// ============================================================
import { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';
import HeroSection from './sections/HeroSection';
import StatsSection from './sections/StatsSection';
import FeaturedProperties from './sections/FeaturedProperties';
import WhyOVDC from './sections/WhyOVDC';
import ProjectsPreview from './sections/ProjectsPreview';
import TestimonialsSection from './sections/TestimonialsSection';
import ContactCTA from './sections/ContactCTA';

export default function HomePage() {
  useEffect(() => {
    AOS.init({ duration: 800, once: true, offset: 80 });
  }, []);

  return (
    <main className="page-enter">
      <HeroSection />
      <StatsSection />
      <FeaturedProperties />
      <WhyOVDC />
      <ProjectsPreview />
      <TestimonialsSection />
      <ContactCTA />
    </main>
  );
}
