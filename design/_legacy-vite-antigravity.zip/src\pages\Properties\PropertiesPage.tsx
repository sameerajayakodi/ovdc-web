// ============================================================
// OVDC — Properties Listing Page
// ============================================================
import { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import PropertyCard from '../../components/PropertyCard';
import { useOvdcStore } from '../../store/ovdcStore';
import type { PropertyType, PropertyStatus } from '../../types';
import './PropertiesPage.css';

const TYPES: { value: '' | PropertyType; label: string }[] = [
  { value: '',            label: 'All Types' },
  { value: 'apartment',  label: 'Apartment' },
  { value: 'villa',      label: 'Villa' },
  { value: 'penthouse',  label: 'Penthouse' },
  { value: 'studio',     label: 'Studio' },
  { value: 'duplex',     label: 'Duplex' },
];

const STATUSES: { value: '' | PropertyStatus; label: string }[] = [
  { value: '',                 label: 'Any Status' },
  { value: 'available',        label: 'Available' },
  { value: 'under_construction', label: 'Under Construction' },
  { value: 'sold',             label: 'Sold' },
];

const CITIES = ['', 'Colombo', 'Galle', 'Unawatuna'];

export default function PropertiesPage() {
  const { properties } = useOvdcStore();
  const [search,   setSearch]   = useState('');
  const [type,     setType]     = useState<'' | PropertyType>('');
  const [status,   setStatus]   = useState<'' | PropertyStatus>('');
  const [city,     setCity]     = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [showFilter, setShowFilter] = useState(false);

  const filtered = useMemo(() => {
    return properties.filter((p) => {
      if (search && !p.title.toLowerCase().includes(search.toLowerCase()) &&
          !p.location.toLowerCase().includes(search.toLowerCase())) return false;
      if (type   && p.type   !== type)   return false;
      if (status && p.status !== status) return false;
      if (city   && p.city   !== city)   return false;
      if (minPrice && p.price < Number(minPrice) * 1_000_000) return false;
      if (maxPrice && p.price > Number(maxPrice) * 1_000_000) return false;
      return true;
    });
  }, [properties, search, type, status, city, minPrice, maxPrice]);

  const clearFilters = () => {
    setSearch(''); setType(''); setStatus(''); setCity('');
    setMinPrice(''); setMaxPrice('');
  };

  const hasFilters = search || type || status || city || minPrice || maxPrice;

  return (
    <div className="props-page">
      {/* Page Header */}
      <div className="props-hero bg-navy-gradient">
        <div className="container props-hero-content">
          <span className="section-label" style={{color:'rgba(201,168,76,0.9)'}}>Portfolio</span>
          <h1 className="section-title light">All Properties</h1>
          <span className="gold-divider center" />
          <p className="section-desc light" style={{margin:'12px auto 0', textAlign:'center'}}>
            Discover your perfect coastal residence from our curated collection.
          </p>
        </div>
      </div>

      <div className="container props-layout">
        {/* Filters Bar */}
        <div className="props-filter-bar">
          <div className="props-search-wrap">
            <Search size={16} className="props-search-icon" />
            <input
              id="props-search"
              type="text"
              className="form-input props-search"
              placeholder="Search properties or locations…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="props-filters-row">
            <select id="filter-type" className="form-select" value={type} onChange={(e) => setType(e.target.value as any)}>
              {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
            <select id="filter-status" className="form-select" value={status} onChange={(e) => setStatus(e.target.value as any)}>
              {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
            <select id="filter-city" className="form-select" value={city} onChange={(e) => setCity(e.target.value)}>
              {CITIES.map((c) => <option key={c} value={c}>{c || 'All Cities'}</option>)}
            </select>
            <input
              id="filter-min-price"
              type="number"
              className="form-input"
              placeholder="Min LKR (M)"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
              style={{ width: 130 }}
            />
            <input
              id="filter-max-price"
              type="number"
              className="form-input"
              placeholder="Max LKR (M)"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
              style={{ width: 130 }}
            />
            {hasFilters && (
              <button className="btn btn-outline-gold props-clear-btn" onClick={clearFilters} id="filter-clear-btn">
                <X size={14} /> Clear
              </button>
            )}
          </div>
        </div>

        {/* Results count */}
        <div className="props-results-meta">
          <span>{filtered.length} propert{filtered.length !== 1 ? 'ies' : 'y'} found</span>
          {hasFilters && <span className="props-filter-active">Filters active</span>}
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="props-grid">
            {filtered.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        ) : (
          <div className="props-empty">
            <p>No properties match your filters.</p>
            <button className="btn btn-outline-gold" onClick={clearFilters}>Clear Filters</button>
          </div>
        )}
      </div>
    </div>
  );
}
