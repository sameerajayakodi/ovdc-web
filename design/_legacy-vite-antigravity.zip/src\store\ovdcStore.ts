// ============================================================
// OVDC — Zustand Store (Admin + Public State)
// localStorage persistence via zustand/middleware
// ============================================================
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Property, Project, Inquiry, SiteSettings } from '../types';
import { MOCK_PROPERTIES, MOCK_PROJECTS, DEFAULT_SETTINGS } from '../data/mockData';

interface OvdcStore {
  // Auth
  isAuthenticated: boolean;
  login: (password: string) => boolean;
  logout: () => void;

  // Properties
  properties: Property[];
  addProperty: (p: Property) => void;
  updateProperty: (id: string, updates: Partial<Property>) => void;
  deleteProperty: (id: string) => void;

  // Projects
  projects: Project[];
  addProject: (p: Project) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;

  // Inquiries
  inquiries: Inquiry[];
  addInquiry: (inq: Inquiry) => void;
  updateInquiryStatus: (id: string, status: Inquiry['status']) => void;
  deleteInquiry: (id: string) => void;

  // Settings
  settings: SiteSettings;
  updateSettings: (updates: Partial<SiteSettings>) => void;
}

export const useOvdcStore = create<OvdcStore>()(
  persist(
    (set, get) => ({
      // ── Auth ──────────────────────────────────────────────
      isAuthenticated: false,
      login: (password) => {
        if (password === get().settings.adminPassword) {
          set({ isAuthenticated: true });
          return true;
        }
        return false;
      },
      logout: () => set({ isAuthenticated: false }),

      // ── Properties ────────────────────────────────────────
      properties: MOCK_PROPERTIES,
      addProperty: (p) =>
        set((s) => ({ properties: [...s.properties, p] })),
      updateProperty: (id, updates) =>
        set((s) => ({
          properties: s.properties.map((p) =>
            p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
          ),
        })),
      deleteProperty: (id) =>
        set((s) => ({ properties: s.properties.filter((p) => p.id !== id) })),

      // ── Projects ──────────────────────────────────────────
      projects: MOCK_PROJECTS,
      addProject: (p) =>
        set((s) => ({ projects: [...s.projects, p] })),
      updateProject: (id, updates) =>
        set((s) => ({
          projects: s.projects.map((p) => (p.id === id ? { ...p, ...updates } : p)),
        })),
      deleteProject: (id) =>
        set((s) => ({ projects: s.projects.filter((p) => p.id !== id) })),

      // ── Inquiries ─────────────────────────────────────────
      inquiries: [],
      addInquiry: (inq) =>
        set((s) => ({ inquiries: [inq, ...s.inquiries] })),
      updateInquiryStatus: (id, status) =>
        set((s) => ({
          inquiries: s.inquiries.map((i) => (i.id === id ? { ...i, status } : i)),
        })),
      deleteInquiry: (id) =>
        set((s) => ({ inquiries: s.inquiries.filter((i) => i.id !== id) })),

      // ── Settings ──────────────────────────────────────────
      settings: DEFAULT_SETTINGS,
      updateSettings: (updates) =>
        set((s) => ({ settings: { ...s.settings, ...updates } })),
    }),
    {
      name: 'ovdc-store',
      // Don't persist auth state across page refreshes
      partialize: (state) => ({
        properties: state.properties,
        projects: state.projects,
        inquiries: state.inquiries,
        settings: state.settings,
      }),
    }
  )
);
